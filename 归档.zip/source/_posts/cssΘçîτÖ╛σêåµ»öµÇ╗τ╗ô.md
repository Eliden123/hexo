---
draft: false
showonlyimage: true
writer: "eliden"
image: "headerimg/1.jpg"
date: "2018-09-05"
categories: [ "H5C3"]
weight: 4
title: "css里百分比总结"
---

<!--more-->

background-position的百分比
横轴 100px 就是背景图向右移动100px像素

设置百分比值 = （容器宽度 - 背景宽度）*百分比




background-size的百分比